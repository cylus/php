<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "registration";
 
/* Attempt to connect to MySQL database */
$link = mysqli_connect($host, $user, $password, $database);
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
?>